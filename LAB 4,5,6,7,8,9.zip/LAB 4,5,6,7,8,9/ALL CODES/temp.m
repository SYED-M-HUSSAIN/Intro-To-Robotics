y = -9
if (y < -15)
    y_correction_factor = 0
elseif ( -15 < y && y < -10)
    y_correction_factor = 1
elseif (y > -10)
    y_correction_factor = 1.5
end